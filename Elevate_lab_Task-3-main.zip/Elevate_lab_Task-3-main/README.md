# Elevate_lab_Task-3
This is my Task-3 as a Intern in Elevate Labs for a month during a period of 26/05/2025 - 26/06/2025

My task is Housing Price Predicition using Multiple Linear Regression . Now I am done with my Model by prediciting the accuracy of 64% . Accuracy is low so i will improve the prediciting accuracy in my model as soon .
